/* =============================================================
   PBL ConsultING – script.js
   Stand: 16.04.2026
   Enthält:
   1. Mobile-Menü (open/close)
   2. Nav-Farbwechsel beim Scrollen
   3. Scroll-Reveal-Animationen
   4. Cursor-Effekte (Glow + Dot)
   5. Kontaktformular-Handling
   6. Werkzeug-Tisch: Hotspot-Tooltip & Klick-Highlight
   7. Smooth-Scroll mit Nav-Offset
   ============================================================= */

(function () {
  'use strict';

  /* -----------------------------------------------------------
     1. MOBILE-MENÜ
  ----------------------------------------------------------- */
  const mobileMenu = document.getElementById('mobileMenu');

  window.openMobile = function () {
    if (mobileMenu) {
      mobileMenu.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  };
  window.closeMobile = function () {
    if (mobileMenu) {
      mobileMenu.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  // Esc schließt das Menü
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') window.closeMobile();
  });

  /* -----------------------------------------------------------
     2. NAV-FARBWECHSEL BEIM SCROLLEN
     Nach 80px Scrollweg wird die Nav hell (weiß statt dunkel).
  ----------------------------------------------------------- */
  const navEl = document.querySelector('nav');
  function updateNavOnScroll() {
    if (!navEl) return;
    if (window.scrollY > 80) {
      navEl.classList.add('nav-light');
    } else {
      navEl.classList.remove('nav-light');
    }
  }
  window.addEventListener('scroll', updateNavOnScroll, { passive: true });
  updateNavOnScroll();

  /* -----------------------------------------------------------
     3. SCROLL-REVEAL
     Elemente mit Klasse .reveal werden sichtbar, sobald sie
     in den Viewport kommen. Verzögerungs-Klassen: .reveal-delay-1..4
  ----------------------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    revealEls.forEach((el) => io.observe(el));
  } else {
    // Fallback: einfach alles anzeigen
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* -----------------------------------------------------------
     4. CURSOR-EFFEKTE (nur Desktop mit echter Maus)
  ----------------------------------------------------------- */
  const glow = document.getElementById('cursorGlow');
  const dot = document.getElementById('cursorDot');
  const hasFinePointer =
    window.matchMedia && window.matchMedia('(pointer: fine)').matches;

  if (glow && dot && hasFinePointer) {
    let mouseX = 0, mouseY = 0;
    let glowX = 0, glowY = 0;

    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      dot.style.transform = `translate(${mouseX}px, ${mouseY}px)`;
    });

    // Weicher Follow-Effekt für den Glow
    function animateGlow() {
      glowX += (mouseX - glowX) * 0.15;
      glowY += (mouseY - glowY) * 0.15;
      glow.style.transform = `translate(${glowX}px, ${glowY}px)`;
      requestAnimationFrame(animateGlow);
    }
    animateGlow();

    // Hover-Effekt auf interaktiven Elementen
    const interactive = document.querySelectorAll(
      'a, button, .tool-hotspot, .leistung-card, input, select, textarea'
    );
    interactive.forEach((el) => {
      el.addEventListener('mouseenter', () => {
        glow.classList.add('cursor-glow--active');
        dot.classList.add('cursor-dot--active');
      });
      el.addEventListener('mouseleave', () => {
        glow.classList.remove('cursor-glow--active');
        dot.classList.remove('cursor-dot--active');
      });
    });
  } else if (glow && dot) {
    // Auf Touch-Geräten komplett ausblenden
    glow.style.display = 'none';
    dot.style.display = 'none';
  }

  /* -----------------------------------------------------------
     5. KONTAKTFORMULAR
     Erwartet ein Element mit id="form-success" im Form.
     HINWEIS: Die Anbindung an den Mail-Versand (IONOS / PHP-Mailer
     oder Formspree) erfolgt später über den Hoster. Aktuell wird
     die Erfolgsmeldung nach kurzer Verzögerung eingeblendet.
  ----------------------------------------------------------- */
  window.handleSubmit = function (event) {
    event.preventDefault();
    const form = event.target;
    const successBox = document.getElementById('form-success');

    // Simulierter Versand (später durch echten Endpoint ersetzen)
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Wird gesendet …';
    }

    setTimeout(() => {
      if (successBox) successBox.style.display = 'block';
      form.reset();
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Anfrage senden →';
      }
      // Erfolg-Box nach 8 Sekunden ausblenden
      setTimeout(() => {
        if (successBox) successBox.style.display = 'none';
      }, 8000);
    }, 600);

    return false;
  };

  /* -----------------------------------------------------------
     6. WERKZEUG-TISCH: HOTSPOT-TOOLTIP & KLICK-HIGHLIGHT
  ----------------------------------------------------------- */
  const toolsWrap = document.getElementById('toolsWrap');
  const tooltip = document.getElementById('toolsTooltip');
  const tooltipName = document.getElementById('toolsTooltipName');
  const tooltipDesc = document.getElementById('toolsTooltipDesc');
  const hotspots = document.querySelectorAll('.tool-hotspot');
  const toolPills = document.querySelectorAll('.tool-pill');

  if (toolsWrap && tooltip && hotspots.length) {
    hotspots.forEach((spot) => {
      // Tooltip einblenden bei Hover / Focus
      const showTooltip = () => {
        tooltipName.textContent = spot.dataset.name || '';
        tooltipDesc.textContent = spot.dataset.desc || '';
        tooltip.classList.add('is-visible');

        // Position: mittig über dem Hotspot
        const wrapRect = toolsWrap.getBoundingClientRect();
        const spotRect = spot.getBoundingClientRect();
        const x = spotRect.left - wrapRect.left + spotRect.width / 2;
        const y = spotRect.top - wrapRect.top;
        tooltip.style.left = x + 'px';
        tooltip.style.top = y + 'px';

        // Zugehörige Pill visuell hervorheben
        const key = spot.dataset.leistung;
        toolPills.forEach((p) => {
          p.classList.toggle('is-active', p.dataset.leistung === key);
        });
      };

      const hideTooltip = () => {
        tooltip.classList.remove('is-visible');
        toolPills.forEach((p) => p.classList.remove('is-active'));
      };

      spot.addEventListener('mouseenter', showTooltip);
      spot.addEventListener('focus', showTooltip);
      spot.addEventListener('mouseleave', hideTooltip);
      spot.addEventListener('blur', hideTooltip);

      // Klick = sanftes Scrollen zur Leistung (wird unten global gehandhabt)
    });
  }

  /* -----------------------------------------------------------
     7. SMOOTH-SCROLL MIT NAV-OFFSET
     Alle Anker-Links (#section) scrollen weich und berücksichtigen
     die fixe Navigation (ca. 90px hoch).
  ----------------------------------------------------------- */
  const NAV_OFFSET = 90;
  const anchorLinks = document.querySelectorAll('a[href^="#"]');

  anchorLinks.forEach((link) => {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (!targetId || targetId === '#') return;

      const target = document.querySelector(targetId);
      if (!target) return;

      e.preventDefault();
      const topPos =
        target.getBoundingClientRect().top + window.scrollY - NAV_OFFSET;
      window.scrollTo({ top: topPos, behavior: 'smooth' });

      // Ziel-Leistungskarte kurz hervorheben (wenn vorhanden)
      if (target.classList.contains('leistung-card')) {
        target.classList.add('is-highlight');
        setTimeout(() => target.classList.remove('is-highlight'), 1600);
      }

      // Mobile-Menü nach Klick schließen
      window.closeMobile();
    });
  });

})();
