# PBL ConsultING – Übergabe an den nächsten Chat

**Stand:** 16. April 2026
**Dateien im Paket:** `index.html`, `style.css`, `script.js`, `UEBERGABE.md`

---

## ✅ Bereits erledigt (frühere Sessions)

- Marke durchgängig auf **PBL ConsultING**
- **DEKRA** statt DIBt eingetragen (Hero, Stats, Zertifikate)
- Zahlen rechtssicher entschärft: 100+, 15+, DEKRA, 6 Fachbereiche
- Sprachfehler „eine Sprache auf dem Bau" korrigiert
- Unvollständige Formulierung bei „Digitale Projektbegleitung"
- Überschrift „Welche Zertifizierung?" → „Zertifizierungskompetenz"
- Alle Leistungsbilder ausgetauscht
- Kontaktformular-Select vervollständigt (Energieberatung + Planungsmanagement)
- Footer-Leistungsmenü ergänzt, Copyright auf 2026

## ✅ In dieser Session erledigt

- **Prozess-Schritt 1** umformuliert: „Kostenfreie Analyse" → **„Unverbindliches Erstgespräch zur Zielklärung und Vorgehensabstimmung"**
- **Trust-Sektion** komplett umgebaut (UWG-konform, keine Zitate mehr):
  - Überschrift: „Was unsere Kunden sagen" → **„Wen wir begleiten"**
  - Eyebrow: „Vertrauen & Referenzen" → **„Kundengruppen & Einsatzbereiche"**
  - 6 Branchen-Kacheln: Privatkunden · Bauträger & Investoren · Wohnungsbaugesellschaften · Hausverwaltungen · Architektur- & Planungsbüros · Sanierungsprojekte
  - Kennzahlen-Block (100+ / 15+ / DEKRA / 6 Fachbereiche) bleibt erhalten
- **Bulli-SVG-Sektion komplett entfernt** und durch **Werkzeug-Tisch mit Hotspots** ersetzt:
  - Neues KI-Bild `images/werkzeuge-tisch.jpg` als Hintergrund
  - 6 klickbare Hotspots (prozentual positioniert, responsive) mit Tooltip
  - Fallback-Pills darunter für Mobile und schnelle Navigation
  - Hotspot-Zuordnung:
    - Feuchtemessgerät → Bauschadenbewertung
    - Wärmebildkamera → Energieberatung iSFP
    - Laser-Entfernungsmesser → Hauskaufberatung
    - Baupläne → Planungsmanagement
    - DGNB-Mappe → Gebäudezertifizierung
    - iPad mit 3D-Modell → BIM Planung
- **`script.js` komplett neu geschrieben** – enthält alle Funktionen:
  1. Mobile-Menü (open/close + Esc-Key)
  2. Nav-Farbwechsel beim Scrollen (nav-light ab 80px)
  3. Scroll-Reveal mit IntersectionObserver
  4. Cursor-Effekte (nur Desktop, Touch-Geräte: ausgeblendet)
  5. Kontaktformular-Handling (aktuell simuliert – siehe To-Do #2)
  6. Werkzeug-Tisch: Hotspot-Tooltip + Pill-Highlight
  7. Smooth-Scroll mit Nav-Offset + Leistungskarten-Highlight
- **CSS-Ergänzungsdatei `style-additions.css`** erstellt – muss einmalig ans Ende von `style.css` kopiert werden (enthält Reveal-States, Cursor, Mobile-Menü, Tools-Sektion, Karten-Highlight)

---

## ⚠️ WICHTIG: Vor dem nächsten Live-Gang zu erledigen

1. **Bild hochladen:** `images/werkzeuge-tisch.jpg` in den Bilder-Ordner der Site legen
2. **CSS mergen:** Inhalt von `style-additions.css` ans Ende von `style.css` kopieren (einmalig), dann `style-additions.css` löschen
3. **Kontaktformular an Mail-Versand anbinden:** aktuell im `script.js` simuliert (setTimeout). Echte Anbindung nötig – Optionen:
   - PHP-Mailer bei IONOS (empfohlen, bleibt in eigener Hand)
   - Formspree / Formsubmit (externer Dienst, DSGVO-Prüfung nötig)

---

## 🔴 Für nächsten Chat: Rechtsseiten

### Angaben von Niels (vollständig, bis auf einen Punkt)

| Feld | Wert |
|---|---|
| Inhaber | Niels Sonnenberg |
| Rechtsform | Einzelunternehmen |
| Geschäftsanschrift | Habichtstr. 12, 32602 Vlotho |
| Telefon | +49 155 671 793 73 |
| E-Mail | n.sonnenberg@pbl-consulting.de |
| Website | www.PBL-ConsultING.de |
| USt-Status | **Kleinunternehmer nach § 19 UStG** |
| Kammer | Ingenieurkammer-Bau NRW |
| Mitgliedsnummer | **749226** |
| Berufsbezeichnung | **Bauvorlageberechtigter Bauingenieur** (verliehen in Deutschland) |
| Hosting-Provider | **IONOS SE**, Elgendorfer Str. 57, 56410 Montabaur |
| Formular-Empfang | direkt per Mail an n.sonnenberg@pbl-consulting.de |
| Tracking | **keines** |
| Cookies | **keine** |
| Cookie-Banner | **nicht erforderlich** |
| Zahlungsziel | 14 Tage |
| Gerichtsstand | Vlotho |

### ✅ Berufshaftpflichtversicherung (vollständig)

| Feld | Wert |
|---|---|
| Versicherer | **EUROMAF S.A., Niederlassung für Deutschland** |
| Anschrift | Kaistr. 13, 40221 Düsseldorf |
| Räumlicher Geltungsbereich | Deutschland und EU *(für Impressum ausreichend; ggf. in nächster Session mit Niels final bestätigen)* |
| Vermittelt durch | AIA AG (Versicherungsmakler, gleiche Anschrift) – im Impressum nicht erforderlich |

**Hinweis zur Einordnung:** EUROMAF ist eine französische Spezialversicherung für Architekten und Ingenieure mit deutscher Niederlassung in Düsseldorf. Die AIA AG am selben Standort ist die exklusive Partner-Maklerin. Das ist eine bei Ingenieurkammern gängige und rechtlich unkritische Konstellation.

Damit sind **alle Angaben für die Rechtsseiten vollständig** – im nächsten Chat kann Impressum/Datenschutz/AGB ohne Rückfragen gebaut werden.

---

## 📋 Priorisierte To-Do-Liste für nächsten Chat

1. **Rechtsseiten erstellen** (höchste Priorität, sobald Versicherer vorliegt):
   - `impressum.html`
   - `datenschutz.html` (schlank – kein Tracking, keine Cookies, nur IONOS-Hosting + Kontaktformular + lokal gehostete Fonts)
   - `agb.html` (14 Tage Zahlungsziel, Gerichtsstand Vlotho, Haftungsbegrenzung auf Deckungssumme, Widerrufsbelehrung für Verbraucher)
2. **Footer + DSGVO-Checkbox** mit echten Links zu den Rechtsseiten verknüpfen (aktuell alle `href="#"`)
3. **Google Fonts lokal hosten** (DSGVO-kritisch, aktuell Zeilen 13–14 in index.html)
4. **Kontaktformular-Mailversand** an IONOS/PHP-Mailer anbinden (derzeit nur simuliert in `script.js`)
5. **Structured Data** (JSON-LD `ProfessionalService`-Schema in den `<head>`)
6. **Logo-Nav refactoren** (`margin-top:-55px` in index.html Zeile 31 sauber via CSS lösen)
7. **Mobile-Check** (Breakpoints, Menu, Werkzeug-Tisch-Hotspots auf Touch, Formular, Stats-Grid, Branchen-Grid)
8. **Hotspot-Positionen feintunen** – nach erstem Live-Test auf echtem Bild prüfen, ob die %-Werte exakt auf den Geräten sitzen

---

## 💬 Einstiegs-Prompt für nächsten Chat

> Hi Claude, ich möchte an der PBL-ConsultING-Website weiterarbeiten. Im Anhang: `index.html`, `style.css`, `script.js` und `UEBERGABE.md`. Bitte lies zuerst `UEBERGABE.md` – dort stehen alle Entscheidungen, Angaben und offenen Punkte vollständig. Bauen wir bitte die drei Rechtsseiten (Impressum, Datenschutz, AGB) und verknüpfen anschließend Footer + DSGVO-Checkbox mit den neuen Links.
