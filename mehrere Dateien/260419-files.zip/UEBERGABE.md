# PBL ConsultING – Übergabedatei
**Stand: April 2026 | Datei: `pbl-merged.html`**

---

## Was wurde erstellt

Vollständige Single-File-Website (`pbl-merged.html`) als Zusammenführung von:
- **`index-all-in-one.html`** – Basis (HTML, CSS, JS, Bulli-Video-Hero, Werkzeug-Tisch, Bulli-SVG-Explorer)
- **`pbl-complete_1.html`** – Extras (Leistungs-Animation, Shader-Background, 3D-Münz-Logo)

---

## Enthaltene Sektionen (Seitenreihenfolge)

| # | Sektion | ID / Klasse | Besonderheit |
|---|---------|-------------|--------------|
| 1 | Navigation | `nav` | Logo-Bild (`img_2.png`), scrollt zu hell/dunkel |
| 2 | Hero | `#hero` | Video-Background (`bulli_video.mp4`), Stats |
| 3 | **Leistungs-Animation** *(neu)* | `.leistungs-anim-section` | Canvas Vaporize-Text, alle 6 Leistungen |
| 4 | Über uns | `#ueber-uns` | 6 Icon-Cards, Foto |
| 5 | Werkzeug-Tisch | `#tools-explorer` | Foto mit Hotspots, Tooltip, Pills |
| 6 | Bulli SVG-Explorer | `#bulli-explorer` | SVG-Van, Tür öffnet sich, Werkzeuge klickbar |
| 7 | Leistungen | `#leistungen` | 6 Karten mit Bild-Kreisen |
| 8 | Prozess | `#prozess` | **WebGL Shader-Hintergrund** *(neu)* |
| 9 | Kundengruppen / Trust | `#referenzen` | 6 Gruppen + Kennzahlen-Leiste |
| 10 | Zertifikate | `.certs` | 5 Zertifikats-Karten |
| 11 | Partner | `#partner` | 5 Partner-Cards |
| 12 | Kontakt | `#kontakt` | Formular + Info-Spalte |
| 13 | **3D-Münz-Logo** *(neu)* | `.logo3d-section` | Three.js, drehbar, zoombar |
| 14 | Footer | `footer` | 4-spaltig, Legal-Links |

---

## Technische Abhängigkeiten

### Externe CDNs (Internetverbindung nötig)
```
Google Fonts:
  - DM Serif Display / DM Sans / Bebas Neue
  - Cormorant Garamond (für Leistungs-Animation)

Three.js r128:
  https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
```

### Lokale Dateien (müssen im Ordner `images/` liegen)
```
images/
  img_2.png         → Logo (Nav + Hero-Overlay + 3D-Münze)
  img_6.png         → IK Bau NRW Logo
  img_7.png         → Partner: BIMpixel
  img_8.png         → Partner: Projekt Partner Glawe
  img_9.png         → Partner: BauConcept GmbH
  img_10.png        → Partner: Plavanti
  img_11.png        → Partner: M. B. Consulting
  img_12.png        → DGNB Auditor Badge
  img_13.png        → DGNB ESG-Manager Badge
  img_14.png        → Energieeffizienz-Experte Badge
  werkzeuge-tisch.jpg → Foto für Werkzeug-Tisch-Hotspots
  bulli_video.mp4   → Hero-Hintergrundvideo
```

---

## JavaScript-Module (alle in einem `<script>`-Block per IIFE)

| Modul | Funktion |
|-------|----------|
| Mobile-Menü | `openMobile()` / `closeMobile()` / ESC-Taste |
| Nav-Scroll | Wechsel dunkel ↔ hell nach 80 px |
| Scroll-Reveal | `.reveal` → `.visible` via IntersectionObserver |
| Cursor-Glow | Gold-Ring folgt Maus (Desktop only) |
| Kontaktformular | `handleSubmit()` – simulierter Versand |
| Werkzeug-Tisch | Hotspot-Tooltip + Pill-Highlight + Scroll |
| Smooth-Scroll | Alle `#`-Links mit 90 px Nav-Offset |

**Separate Script-Blöcke:**
- Leistungs-Animation (Canvas Particle-Vaporize)
- WebGL Shader-Background (Prozess-Sektion)
- Three.js 3D-Münz-Logo (Drag, Zoom, Auto-Rotate)

---

## Offene Aufgaben (nicht in dieser Datei enthalten)

### Rechtliche Seiten
- [ ] `impressum.html` anlegen (Pflichtangaben: Name, Adresse, USt-ID, Berufshaftpflicht, Kammer)
- [ ] `datenschutz.html` anlegen (DSGVO: Google Fonts → lokal hosten oder ersetzen)
- [ ] Links im Footer (`href="#"`) auf echte Seiten setzen

### Formular-Anbindung
- [ ] `handleSubmit()` in `script.js` → echten Endpunkt eintragen
  - Option A: IONOS PHP-Mailer (`mail.php` im Stammverzeichnis)
  - Option B: Formspree `https://formspree.io/f/XXXX`

### Fehlende Geschäftsdaten
- [ ] USt-ID / Steuer-Nr. (für Impressum)
- [ ] Versicherungsname + Geltungsbereich (für Impressum)
- [ ] Hosting-Anbieter (IONOS?) für Datenschutz

### DSGVO: Google Fonts
Google Fonts laden aktuell von `fonts.googleapis.com` → IP-Übertragung.
Lösung: Fonts lokal hosten oder Cookie-Consent voranschalten.

### Bulli-SVG Explorer
Der SVG-Bulli ist vorhanden und voll funktionsfähig.  
Hinweis: Sektion hat **keinen** Dienst-Abschnitt im Services-Strip verlinkt –  
bei Bedarf `href`-Targets in den `.bulli-pill`-Links prüfen.

---

## Nächste Session – Empfohlene Einstiegs-Prompt

```
Wir arbeiten an der PBL ConsultING Website (pbl-merged.html).
Stand: Alle Sektionen und Extras sind integriert (Leistungs-Animation,
Shader-Background, 3D-Münz-Logo, Werkzeug-Tisch, Bulli-Explorer).

Heute: [AUFGABE EINTRAGEN]
Offene Punkte lt. UEBERGABE.md:
- Impressum / Datenschutz anlegen
- Formular anbinden (IONOS oder Formspree)
- Google Fonts lokal hosten
```

---

## Dateiübersicht

```
pbl-merged.html   → Finale Gesamt-Datei (221 KB, 2438 Zeilen)
UEBERGABE.md      → Diese Datei
images/           → Lokale Bilder (separat bereitstellen)
```
