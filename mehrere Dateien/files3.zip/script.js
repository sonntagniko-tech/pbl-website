// Scroll reveal
  const reveals = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  reveals.forEach(el => io.observe(el));

  // Mobile menu
  function openMobile() { document.getElementById('mobileMenu').classList.add('open'); document.body.style.overflow='hidden'; }
  function closeMobile() { document.getElementById('mobileMenu').classList.remove('open'); document.body.style.overflow=''; }

  // Nav scroll – wechselt zwischen dunklem und hellem Hintergrund
  const nav = document.querySelector('nav');
  const lightSections = ['ueber-uns', 'leistungen', 'prozess', 'partner'];

  function updateNav() {
    const scrollY = window.scrollY;
    nav.style.padding = scrollY > 60 ? '0.55rem 4rem' : '0.75rem 4rem';

    // Prüfe welche Sektion gerade sichtbar ist
    let isLight = false;
    lightSections.forEach(id => {
      const sec = document.getElementById(id);
      if (!sec) return;
      const rect = sec.getBoundingClientRect();
      if (rect.top <= 80 && rect.bottom >= 80) isLight = true;
    });
    nav.classList.toggle('nav-light', isLight);
  }

  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();

  // Form
  function handleSubmit(e) {
    e.preventDefault();
    document.getElementById('form-success').style.display = 'block';
    e.target.reset();
    setTimeout(() => { document.getElementById('form-success').style.display = 'none'; }, 6000);
  }

  // Smooth scroll für nav
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

// Custom cursor
const glow = document.getElementById('cursorGlow');
const dot = document.getElementById('cursorDot');
let mx = 0, my = 0;

document.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;

  if (dot) { dot.style.left = mx + 'px'; dot.style.top = my + 'px'; }
  if (glow) { glow.style.left = mx + 'px'; glow.style.top = my + 'px'; }

  // 3D tilt on cards
  const cards = document.querySelectorAll('.leistung-card, .about-icon-card, .trust-card, .partner-card');
  cards.forEach(card => {
    const rect = card.getBoundingClientRect();
    if (mx >= rect.left && mx <= rect.right && my >= rect.top && my <= rect.bottom) {
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const rx = ((my - cy) / (rect.height / 2)) * 8;
      const ry = ((mx - cx) / (rect.width / 2)) * -8;
      card.style.transform = `perspective(600px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-5px)`;
    } else {
      card.style.transform = '';
    }
  });

  // Hero parallax
  const hero = document.querySelector('.hero');
  if (hero) {
    const hw = window.innerWidth, hh = window.innerHeight;
    const px = (mx / hw - 0.5) * 12;
    const py = (my / hh - 0.5) * 8;
    const gridLines = hero.querySelector('.hero-grid-lines');
    if (gridLines) gridLines.style.transform = `translate(${px}px, ${py}px)`;
  }
});

if (glow && dot) {
  document.addEventListener('mouseenter', () => { glow.style.opacity = '1'; dot.style.opacity = '1'; });
  document.addEventListener('mouseleave', () => { glow.style.opacity = '0'; dot.style.opacity = '0'; });
}

// Scale cursor on clickable elements
document.querySelectorAll('a, button, .leistung-card, .partner-card').forEach(el => {
  el.addEventListener('mouseenter', () => {
    if (!glow) return;
    glow.style.width = '50px'; glow.style.height = '50px';
    glow.style.borderColor = 'rgba(200,169,110,1)';
  });
  el.addEventListener('mouseleave', () => {
    if (!glow) return;
    glow.style.width = '28px'; glow.style.height = '28px';
    glow.style.borderColor = 'rgba(200,169,110,0.7)';
  });
});
// ===== BULLI INTERACTIVE =====
(function() {
  const wrap = document.getElementById('bulliWrap');
  if (!wrap) return;

  const tooltip = document.getElementById('bulliTooltip');
  const tooltipIcon = document.getElementById('tooltipIcon');
  const tooltipName = document.getElementById('tooltipName');
  const tooltipDesc = document.getElementById('tooltipDesc');
  const pills = document.querySelectorAll('.bulli-pill');

  const toolIcons = {
    tool1: '🔬', tool2: '📷', tool3: '📐',
    tool4: '📏', tool5: '🏅', tool6: '💻'
  };

  // Open/close door on wrap hover
  wrap.addEventListener('mouseenter', () => {
    wrap.classList.add('door-open');
  });
  wrap.addEventListener('mouseleave', () => {
    wrap.classList.remove('door-open');
    tooltip.classList.remove('visible');
    document.querySelectorAll('.werkzeug').forEach(t => t.classList.remove('active-tool'));
    pills.forEach(p => p.classList.remove('active'));
  });

  // Tool hover & click
  document.querySelectorAll('.werkzeug').forEach(tool => {
    tool.addEventListener('mouseenter', (e) => {
      const name = tool.dataset.name;
      const desc = tool.dataset.desc;
      const leistung = tool.dataset.leistung;
      const id = tool.id;

      tooltipIcon.textContent = toolIcons[id] || '🔧';
      tooltipName.textContent = name;
      tooltipDesc.textContent = desc;
      tooltip.classList.add('visible');

      document.querySelectorAll('.werkzeug').forEach(t => t.classList.remove('active-tool'));
      tool.classList.add('active-tool');

      pills.forEach(p => {
        p.classList.toggle('active', p.dataset.leistung === leistung);
      });
    });

    tool.addEventListener('mouseleave', () => {
      tooltip.classList.remove('visible');
      tool.classList.remove('active-tool');
      pills.forEach(p => p.classList.remove('active'));
    });

    tool.addEventListener('click', () => {
      const leistung = tool.dataset.leistung;
      const target = document.getElementById(leistung);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Pills click → smooth scroll
  pills.forEach(pill => {
    pill.addEventListener('click', (e) => {
      e.preventDefault();
      const leistung = pill.dataset.leistung;
      const target = document.getElementById(leistung);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
})();
