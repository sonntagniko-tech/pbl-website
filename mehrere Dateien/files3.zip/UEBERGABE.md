# PBL ConsultING – Übergabe an den nächsten Chat

**Stand:** 16. April 2026
**Dateien im Paket:** `index.html`, `style.css`, `script.js`

---

## ✅ Bereits erledigt (aus vorheriger Session)

- Marke durchgängig auf **PBL ConsultING**
- **DEKRA** statt DIBt eingetragen (Hero, Stats, Zertifikate)
- Zahlen rechtssicher entschärft: 100+, 15+, DEKRA, 6 Fachbereiche
- Sprachfehler „eine Sprache auf dem Bau" korrigiert
- Unvollständige Formulierung bei „Digitale Projektbegleitung"
- Überschrift „Welche Zertifizierung?" → „Zertifizierungskompetenz"
- Alle Leistungsbilder ausgetauscht
- Kontaktformular-Select vervollständigt (Energieberatung + Planungsmanagement)
- Footer-Leistungsmenü ergänzt, Copyright auf 2026

---

## 🟡 In dieser Session geklärt (noch nicht umgesetzt)

### Prozess-Schritt 1
- **Entscheidung:** „Kostenfreie Analyse" → **„unverbindliches Erstgespräch"**
- **Fundstelle:** `index.html`, Zeile 515

### Kundenstimmen (Trust-Sektion)
- **Entscheidung:** Bereich wird zu **„Branchen / Kundengruppen"** umgebaut (ohne Zitate, UWG-konform)
- **Fundstelle:** `index.html`, Zeilen 541–566
- Die drei `trust-card`-Zitate entfernen, stattdessen Kundengruppen-Kacheln (z. B. Privatkunden / Bauträger / Wohnungsbaugesellschaften / Verwaltungen / Architekturbüros / Sanierungsprojekte)
- Überschrift ändern: „Was unsere Kunden sagen" → z. B. „Wen wir begleiten" oder „Unsere Einsatzbereiche"

### Rechtsform & Anschrift
- **Rechtsform:** Einzelunternehmen (Niels Sonnenberg)
- **Geschäftsanschrift:** identisch mit Wohnsitz – **Straße/PLZ/Ort noch offen**
- **USt-Status:** trägt Niels selbst ein
- **Berufshaftpflicht:** Versicherer + räumlicher Geltungsbereich noch offen

---

## 🔴 Offen – Input von Niels erforderlich

### Für Impressum zwingend:
1. **Geschäftsanschrift** (Straße, Hausnummer, PLZ, Ort) – TMG § 5 verlangt ladungsfähige Anschrift
2. **Umsatzsteuer-Status:**
   - Falls USt-ID: „DE…"
   - Falls Kleinunternehmer: „Kleinunternehmer gem. § 19 UStG"
   - Alternativ: Steuernummer
3. **Berufshaftpflichtversicherung** (berufsrechtlich Pflicht für Sachverständige, § 2 DL-InfoV):
   - Name des Versicherers
   - Anschrift des Versicherers
   - Räumlicher Geltungsbereich (meist „weltweit" oder „Deutschland/EU")
4. **Kammerzugehörigkeit:**
   - Ingenieurkammer-Bau NRW (bereits im Footer der Site sichtbar)
   - Berufsbezeichnung: „Beratender Ingenieur" bzw. „Bauingenieur" – bitte exakte Bezeichnung laut Kammer-Eintrag angeben
   - Verliehen in: Deutschland

### Für Datenschutzerklärung:
5. **Hosting-Provider** (z. B. IONOS, Strato, All-Inkl., Hetzner) – für Auftragsverarbeitungs-Hinweis
6. **Formular-Empfang:** Wohin gehen die Kontaktformular-Anfragen? (direkt per Mail? Backend-Datenbank? Drittanbieter wie Formspree?)
7. **Google Fonts:** werden aktuell extern eingebunden (Zeile 13–14) → **DSGVO-kritisch**, Empfehlung lokal hosten (mache ich im nächsten Schritt automatisch)
8. **Tracking/Analytics:** Google Analytics, Matomo, Plausible – ja/nein/welches?
9. **Cookies:** aktuell setzt die Site selbst keine Cookies – bleibt das so?

### Für AGB:
10. **Zahlungsbedingungen** (Zahlungsziel in Tagen, Anzahlung ja/nein)
11. **Haftungsbegrenzung** (empfohlen: bei einfacher Fahrlässigkeit Haftung auf Deckungssumme der Berufshaftpflicht begrenzen)
12. **Widerrufsbelehrung für Verbraucher** (bei Fernabsatzverträgen zwingend)
13. **Anwendbares Recht / Gerichtsstand**

---

## 📋 Priorisierte To-Do-Liste für nächsten Chat

1. **Rechtsseiten erstellen:** `impressum.html`, `datenschutz.html`, `agb.html`
2. **Trust-Sektion umbauen** zu Branchen/Kundengruppen
3. **Prozess-Schritt 1** umformulieren
4. **Footer + DSGVO-Checkbox** mit echten Links verknüpfen
5. **Google Fonts lokal hosten** (DSGVO)
6. **Logo-Nav refactoren** (`margin-top:-55px` sauber lösen, Zeile 31 in `index.html`)
7. **Mobile-Check** (Breakpoints, Menu, Bulli-Verhalten, Formular, Stats-Grid)
8. **Structured Data** (JSON-LD `ProfessionalService`-Schema in den `<head>`)

---

## 💬 Einstiegs-Prompt für nächsten Chat

> Hi Claude, ich möchte an der PBL-ConsultING-Website weiterarbeiten. Im Anhang: `index.html`, `style.css`, `script.js` und `UEBERGABE.md`. Bitte lies zuerst `UEBERGABE.md` – da stehen alle Entscheidungen aus der letzten Session und die offenen Punkte. Fangen wir mit den Rechtsseiten an. Meine Angaben:
>
> - Geschäftsanschrift: [Straße, PLZ Ort]
> - USt: [USt-ID oder Kleinunternehmer oder Steuernummer]
> - Berufshaftpflicht: [Versicherer, Anschrift, Geltungsbereich]
> - Kammer-Berufsbezeichnung: [exakt laut Eintrag]
> - Hosting: [Provider]
> - Formular-Empfang: [z. B. direkt per Mail an n.sonnenberg@pbl-consulting.de]
> - Tracking: [nein / welches]
